import UIKit

class SubCountryModel: NSObject {
    var id:String?
    var idViloyat:String?
    var shahar_name:String?
}

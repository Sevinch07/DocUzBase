import UIKit

class CountryModel: NSObject {
    var id:String?
    var nameViloyat:String?

}

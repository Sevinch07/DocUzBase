import UIKit

class DocModel: NSObject {
    
    var doc_specialist:String?
    var doc_name:String?
    var doc_id:String?
    var doc_image:String?
    
}

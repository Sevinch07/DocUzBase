import UIKit

class TopHospitalModel: NSObject {
        var coment:String?
        var longitude:String?
        var lotitude:String?
        var hospital_name:String?
        var adress:String?
        var image:String?
        var id:String?
        var reyting:String?
    
}

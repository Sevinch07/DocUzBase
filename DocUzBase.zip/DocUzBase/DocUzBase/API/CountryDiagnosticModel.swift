import UIKit

class CountryDiagnosticModel: NSObject {
    var viloyat:String?
    var coment:String?
    var adress :String?
    var shahar_tuman :String?
    var id :String?
    var shahar:String?
    var hospital_name:String?
    var lotitude:String?
    var longitude:String?
    var imageUrl = [String?]()
        
    
}

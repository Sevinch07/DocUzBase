import UIKit

class DocTimeModel: NSObject {
    var time_id:String?
    var data:String?
    var firs_time:String?
    var and_time:String?
}

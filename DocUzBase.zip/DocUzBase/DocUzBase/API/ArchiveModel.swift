import UIKit

class ArchiveModel: NSObject {
    var data:String?
    var diagnostic_test = [String?]()
    var doc_diagnos :String?
    var id_history_table :String?
    var viloyat :String?
    var doc_name:String?
    var doc_phone:String?
    var hospital_name:String?
    var tuman_name:String?
    var doc_prescription:String?
    var diagnosSentre_name:String?
    var natija = [String?]()
}

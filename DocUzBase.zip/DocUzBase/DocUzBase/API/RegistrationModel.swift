//
//  RegistrationModel.swift
//  DocUzBase
//
//  Created by Qodir on 18.03.2023.
//  Copyright © 2023 Qodir. All rights reserved.
//

import UIKit
import SwiftyJSON

class RegistrationModel: NSObject {
    func parseRegistrationInfo(json:JSON) -> String {
        
        return "obj"
    }
}





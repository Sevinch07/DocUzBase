import UIKit

class UserOrderHistoryModel: NSObject {
    var shahar_tuman:String?
    var doc_tur:String?
    var shahar_tuman_name:String?
    var doc_name:String?
    var viloyat:String?
    var doc_phone:String?
    var hospital:String?
    var doc_data:String?
    var first_time:String?
    var end_time:String?
}

class docInfo:NSObject{
    
    
}

import UIKit

class DocInfoModel: NSObject {
        var turi:String?
        var shahar:String?
        var shahar_tuman:String?
        var hospital:String?
        var name:String?
        var image:[String?] = []
        var id:String?
        var coment:String?
        var phone:String?
        var vil:String?
}


import UIKit

class LeftMenuTableViewCell: UITableViewCell {
    @IBOutlet weak var menuLabel:UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }

}

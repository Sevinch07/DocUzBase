import UIKit
class LeftController: UIViewController {
    
    var viewsArray = ["Hospital", "diagnostiks_center","Archive","Profil","ExitProfil"]
    var tableviewsArray = ["Home", "Diagnostik markazlar","Arxiv","Profil","Chiqish"]

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

}


extension LeftController:UITableViewDelegate,UITableViewDataSource{
       func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
           return self.viewsArray.count
       }
       
       func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let exit = self.tableviewsArray[indexPath.row]
        if exit == "Chiqish" {
            UserDefaults.standard.removeObject(forKey: "1")
            UserDefaults.standard.removeObject(forKey: "id")
        }
            let obj = self.viewsArray[indexPath.row]
            self.performSegue(withIdentifier: obj, sender: self)
       }
       
       func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
           let  cell = tableView.dequeueReusableCell(withIdentifier: "LeftMenuTableViewCell", for: indexPath) as! LeftMenuTableViewCell
            let obj = self.tableviewsArray[indexPath.row]
        cell.menuLabel.text = obj
            cell.selectionStyle = .none
            return cell
       }

}


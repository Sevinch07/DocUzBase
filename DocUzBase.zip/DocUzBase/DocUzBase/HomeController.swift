
import UIKit
import MBProgressHUD

class HomeController: UIViewController {
   
    
    var heightSize:CGFloat = 0.0
    var widthSize:CGFloat = 0.0
    var byEmailTextField:Bool = false
     
     
     @IBOutlet weak var customBar:UIView!
     @IBOutlet weak var subCustomBar:UIView!
    
     @IBOutlet weak var barButton:UIButton!
     @IBOutlet weak var sendButton:UIButton!
     @IBOutlet weak var revealButton:UIButton!
     
     
     @IBOutlet weak var segmentControl: UISegmentedControl!
     @IBOutlet weak var forUserNameTextFielld:NSLayoutConstraint!
     @IBOutlet weak var forEmailTextFielld:NSLayoutConstraint!
     
     @IBOutlet weak var userNameTextField: UITextField!
     @IBOutlet weak var userPhoneTextField: UITextField!
     @IBOutlet weak var loginTextField: UITextField!
     @IBOutlet weak var passwordTextField: UITextField!
     @IBOutlet weak var emailTextField: UITextField!
     
     @IBOutlet weak var scrollView:UIScrollView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let id = UserDefaults.standard.string(forKey: "1")
        if id == "1" {
            let vc = self.storyboard?.instantiateViewController(identifier: "HospitalViewController") as! HospitalViewController
            self.navigationController?.pushViewController(vc, animated: true)
        } else {
            let revealViewController = self.revealViewController()
                   revealButton.addTarget(revealViewController, action: #selector(SWRevealViewController.revealToggle(_:)), for: .touchUpInside)
                   self.view.addGestureRecognizer(self.revealViewController()!.panGestureRecognizer())
                   self.revealViewController()?.rearViewRevealWidth = 200
                   
                
                   self.customBar.layer.borderWidth = 3
                    self.customBar.layer.borderColor = UIColor(red:230/255, green:112/255, blue:18/255, alpha: 1).cgColor
                    self.customBar.layer.cornerRadius = 35.0
                    self.customBar.clipsToBounds = true
                    
                    self.subCustomBar.layer.borderWidth = 3
                    self.subCustomBar.layer.borderColor = UIColor(red:255/255, green:255/255, blue:255/255, alpha: 1).cgColor
                    self.subCustomBar.layer.cornerRadius = 20.0
                    self.subCustomBar.clipsToBounds = true
                    
                   self.revealButton.layer.borderWidth = 3
                   self.revealButton.layer.borderColor = UIColor(red:230/255, green:112/255, blue:18/255, alpha: 1).cgColor
                   self.revealButton.layer.cornerRadius = 15.0
                   self.revealButton.clipsToBounds = true
                    
                    let font = UIFont.boldSystemFont(ofSize: 18)

                    let normalAttribute: [NSAttributedString.Key: Any] = [.font: font, .foregroundColor: UIColor(red:230/255, green:112/255, blue:18/255, alpha: 1)]
                    self.segmentControl.setTitleTextAttributes(normalAttribute, for: .normal)

                    let selectedAttribute: [NSAttributedString.Key: Any] = [.font: font, .foregroundColor: UIColor.white]
                    segmentControl.setTitleTextAttributes(selectedAttribute, for: .selected)
                    
                    self.segmentControl.layer.borderWidth = 2
                    self.segmentControl.layer.borderColor = UIColor(red:230/255, green:112/255, blue:18/255, alpha: 1).cgColor

                    self.userNameTextField.layer.borderWidth = 3
                    self.userNameTextField.layer.borderColor = UIColor(red:230/255, green:112/255, blue:18/255, alpha: 1).cgColor
                    self.userNameTextField.layer.cornerRadius = 15.0
                    self.userNameTextField.clipsToBounds = true
                    
                    self.userPhoneTextField.layer.borderWidth = 3
                    self.userPhoneTextField.layer.borderColor = UIColor(red:230/255, green:112/255, blue:18/255, alpha: 1).cgColor
                    
                    self.userPhoneTextField.layer.cornerRadius = 15.0
                    self.userPhoneTextField.clipsToBounds = true
                    self.loginTextField.layer.borderWidth = 3
                    self.loginTextField.layer.borderColor = UIColor(red:230/255, green:112/255, blue:18/255, alpha: 1).cgColor
                    
            
                    self.loginTextField.layer.cornerRadius = 15.0
                    self.loginTextField.clipsToBounds = true
                    self.passwordTextField.layer.borderWidth = 3
                    self.passwordTextField.layer.borderColor = UIColor(red:230/255, green:112/255, blue:18/255, alpha: 1).cgColor
                    self.passwordTextField.layer.cornerRadius = 15.0
                    self.passwordTextField.clipsToBounds = true
                    self.emailTextField.layer.borderWidth = 3
                    self.emailTextField.layer.borderColor = UIColor(red:230/255, green:112/255, blue:18/255, alpha: 1).cgColor
                    self.emailTextField.layer.cornerRadius = 15.0
                    self.emailTextField.clipsToBounds = true
                    self.sendButton.layer.borderWidth = 3
                    self.sendButton.layer.borderColor = UIColor(red:230/255, green:112/255, blue:18/255, alpha: 1).cgColor
                    
            
                    self.sendButton.layer.cornerRadius = 20.0
                    self.sendButton.clipsToBounds = true
                    self.heightSize = self.view.frame.size.height
                    self.widthSize = self.view.frame.size.width
                    self.scrollView.contentSize = CGSize(width: self.widthSize, height: 600)
        }
        
        
        
        
       
        
        
    }
    
    @IBAction func printInTextField(){
        let str = self.emailTextField.text
        self.byEmailTextField = (str?.contains("@"))!
    }
    
    @IBAction func bySegmentControl(){
        if self.segmentControl.selectedSegmentIndex == 0 {
            self.userNameTextField.text = ""
            self.userPhoneTextField.text = ""
            self.loginTextField.text = ""
            self.passwordTextField.text = ""
            self.emailTextField.text = ""
            
            self.userNameTextField.isHidden = true
            self.userPhoneTextField.isHidden = true
            self.emailTextField.isHidden = true
            self.forUserNameTextFielld.constant = 0.0
            self.forEmailTextFielld.constant = 0.0
        } else {
            self.userNameTextField.text = ""
            self.userPhoneTextField.text = ""
            self.loginTextField.text = ""
            self.passwordTextField.text = ""
            self.emailTextField.text = ""
            
            self.userNameTextField.isHidden = false
            self.userPhoneTextField.isHidden = false
            self.emailTextField.isHidden = false
            self.forUserNameTextFielld.constant = 34
            self.forEmailTextFielld.constant = 38
        }
    }
    
    func allertShow(message:String, counter:Int) {
        
        if counter == 1 {
            self.userNameTextField.text = ""
            self.userPhoneTextField.text = ""
            self.loginTextField.text = ""
            self.passwordTextField.text = ""
            self.emailTextField.text = ""
        }
        let alertCont = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        let action = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: {(_) in
        })
        alertCont.addAction(action)
        self.present(alertCont, animated: true, completion: nil)
        
    }
    
    
    @IBAction func sendRestHelper(){
        if self.segmentControl.selectedSegmentIndex == 1 {
            if (self.userNameTextField.text == "") || (self.userPhoneTextField.text == "") || (self.emailTextField.text == "") || (self.loginTextField.text == "") || (self.passwordTextField.text == "") {
                self.allertShow(message: "Barcha maydonlarni to`ldiring", counter: 2)
            } else if self.byEmailTextField == true
                
            {
                let params = ["user_name":self.userNameTextField.text!,"user_phone":self.userPhoneTextField.text!, "log":self.loginTextField.text!, "pas":self.passwordTextField.text!,"email":self.emailTextField.text!,"login":RestHelper.log["login"], "password":RestHelper.log["password"]]
                MBProgressHUD.showAdded(to: self.view, animated: true)
                RestHelper.registrationFunction(params: params as! [String : String], completion: {jsonText,isSuccess   in
                        if isSuccess {
                            MBProgressHUD.hide(for: self.view, animated: true)
                            self.allertShow(message: "Siz registratsiyadan muvofaqiyatli o`ttingiz. Login oynasiga o'ting", counter: 1)
                               
                           }
                       }, failure: { (jsonText, isFailure) in
                           MBProgressHUD.hide(for: self.view, animated: true)
                           if jsonText == "The network connection was lost."{
                            self.allertShow(message: jsonText, counter: 1)
                           } else {
                            self.allertShow(message: "No internet connections", counter: 1)
                           }
                           
                       })
            } else {
                self.allertShow(message: "Email maydoni  xato to`ldirilgan",counter: 2)
                
                }
            }
        else {
            if  (self.loginTextField.text == "") || (self.passwordTextField.text == "") {
                self.allertShow(message: "Barcha maydonlarni to`ldiring", counter: 2)
            } else {
                let params = ["log":self.loginTextField.text!, "pas":self.passwordTextField.text!,"login":RestHelper.log["login"], "password":RestHelper.log["password"]]
                MBProgressHUD.showAdded(to: self.view, animated: true)
                RestHelper.autorizatsiyaFunction(params: params as! [String : String], completion: {jsonText,isSuccess   in
                        if isSuccess {
                            MBProgressHUD.hide(for: self.view, animated: true)
                            if jsonText == "false" {
                                self.allertShow(message: "login yoki parol xato",counter: 1)
                            } else {
                             
                                UserDefaults.standard.set(jsonText, forKey: "id")
                                UserDefaults.standard.set("1", forKey: "1")
                            let vc = self.storyboard?.instantiateViewController(identifier: "HospitalViewController") as! HospitalViewController
                                self.navigationController?.pushViewController(vc, animated: true)}
                               
                           }
                       }, failure: { (jsonText, isFailure) in
                           MBProgressHUD.hide(for: self.view, animated: true)
                           if jsonText == "The network connection was lost."{
                            self.allertShow(message: jsonText, counter: 1)
                           } else {
                            self.allertShow(message: "No internet connections", counter: 1)
                           }
                       })
            
            }
        }
    }
}

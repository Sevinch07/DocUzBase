
import UIKit
import MBProgressHUD
import SDWebImage

class DocHospitalTopListViewController: UIViewController {
    
    var id_hospitals = ""
    var name_hospital = ""
    
    var docArray=[DocModel]()
    
    @IBOutlet weak var docTableView:UITableView!
    
    @IBOutlet weak var backButton:UIButton!
    
    @IBOutlet weak var customBar:UIView!
    @IBOutlet weak var subCustomBar:UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.docArray.removeAll()
       
        self.backButton.layer.borderWidth = 3
        self.backButton.layer.borderColor = UIColor(red:230/255, green:112/255, blue:18/255, alpha: 1).cgColor
        self.backButton.layer.cornerRadius = 15.0
        self.backButton.clipsToBounds = true
        
        self.customBar.layer.borderWidth = 3
        self.customBar.layer.borderColor = UIColor(red:230/255, green:112/255, blue:18/255, alpha: 1).cgColor
        self.customBar.layer.cornerRadius = 35.0
        self.customBar.clipsToBounds = true
        
        self.subCustomBar.layer.borderWidth = 3
        self.subCustomBar.layer.borderColor = UIColor(red:255/255, green:255/255, blue:255/255, alpha: 1).cgColor
        self.subCustomBar.layer.cornerRadius = 20.0
        self.subCustomBar.clipsToBounds = true
        
        self.sendRestHelper()
        
    }
    
    @IBAction func backVC(){
        self.navigationController?.popViewController(animated: true)
    }
    
    func sendRestHelper() {
        let params = ["login":RestHelper.log["login"], "password":RestHelper.log["password"],"id_hospitals":self.id_hospitals]
        MBProgressHUD.showAdded(to: self.view, animated: true)
        RestHelper.docInfoHospitalFunction(params: params as! [String : String], completion: {jsonArray,isSuccess   in
                if isSuccess {
                    MBProgressHUD.hide(for: self.view, animated: true)
                        for js in jsonArray {
                            self.docArray.append(js)
                        }
                    self.docTableView.reloadData()
                    if self.docArray.count == 0 {
                        let text = self.name_hospital + " bo`yicha shifokorlar jamoasi haqida ma`lumot topilmadi"
                        self.allertShow(message: text, counter: 1)
                    }
                       
                   }
               }, failure: { (jsonText, isFailure) in
                   MBProgressHUD.hide(for: self.view, animated: true)
                   if jsonText == "The network connection was lost."{
                    self.allertShow(message: jsonText, counter: 2)
                   } else {
                    self.allertShow(message: "No internet connections", counter: 2)
                   }
               })
    }
    
    
    func allertShow(message:String, counter:Int) {
        let alertCont = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        let action = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: {(_) in
            if counter == 1 {
                self.navigationController?.popViewController(animated: true)
            }
        })
        alertCont.addAction(action)
        self.present(alertCont, animated: true, completion: nil)
        
    }
}

extension DocHospitalTopListViewController:UITableViewDelegate,UITableViewDataSource{
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.docArray.count
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let obj = self.docArray[indexPath.row]
        let vc = self.storyboard?.instantiateViewController(identifier: "DocInfoViewController") as! DocInfoViewController
        
        vc.id_doc = obj.doc_id!
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let  cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCellDoc", for: indexPath) as! TableViewCell
        let obj = self.docArray[indexPath.row]
        cell.labelName.text = obj.doc_name
        let text = RestHelper.BaseURL + obj.doc_image!
        
        if obj.doc_image! == "" {
            cell.img.image = UIImage(named: "icon")
        } else {
            let url = URL(string: text)
            cell.img?.sd_setImage(with: url)
        }
        cell.img.layer.borderWidth = 3
        cell.img.layer.borderColor = UIColor(red:230/255, green:112/255, blue:18/255, alpha: 1).cgColor
        cell.img.layer.cornerRadius = 10.0
        cell.img.clipsToBounds = true
        cell.selectionStyle = .none
        return cell
    }
  
    
    
}

import UIKit
import MBProgressHUD
import SDWebImage

class CountryViewController: UIViewController {

   var heightSize:CGFloat = 0.0
       var widthSize:CGFloat = 0.0
       
       var countryArray=[CountryModel]()
       
       @IBOutlet weak var CountryTableView:UITableView!
       
       @IBOutlet weak var revealButton:UIButton!
       @IBOutlet weak var refreshButton:UIButton!
       @IBOutlet weak var barButton:UIButton!
       
       @IBOutlet weak var customBar:UIView!
       @IBOutlet weak var subCustomBar:UIView!
       
       override func viewDidLoad() {
           super.viewDidLoad()
           
           self.countryArray.removeAll()
           
           heightSize = self.view.frame.size.height
           widthSize = self.view.frame.size.width
           
           self.revealButton.layer.borderWidth = 3
           self.revealButton.layer.borderColor = UIColor(red:230/255, green:112/255, blue:18/255, alpha: 1).cgColor
           self.revealButton.layer.cornerRadius = 15.0
           self.revealButton.clipsToBounds = true
           
           self.refreshButton.layer.borderWidth = 3
           self.refreshButton.layer.borderColor = UIColor(red:230/255, green:112/255, blue:18/255, alpha: 1).cgColor
           self.refreshButton.layer.cornerRadius = 15.0
           self.refreshButton.clipsToBounds = true
           
           self.customBar.layer.borderWidth = 3
           self.customBar.layer.borderColor = UIColor(red:230/255, green:112/255, blue:18/255, alpha: 1).cgColor
           self.customBar.layer.cornerRadius = 35.0
           self.customBar.clipsToBounds = true
           
           self.subCustomBar.layer.borderWidth = 3
           self.subCustomBar.layer.borderColor = UIColor(red:255/255, green:255/255, blue:255/255, alpha: 1).cgColor
           self.subCustomBar.layer.cornerRadius = 20.0
           self.subCustomBar.clipsToBounds = true
           self.sendRestHelper()
           
       }
       
       override func viewWillAppear(_ animated: Bool) {
           super.viewWillAppear(animated)
           heightSize = self.view.frame.size.height
           widthSize = self.view.frame.size.width
       }
       
       
       func sendRestHelper() {
           self.countryArray.removeAll()
           self.CountryTableView.reloadData()
           let params = ["login":RestHelper.log["login"], "password":RestHelper.log["password"]]
           MBProgressHUD.showAdded(to: self.view, animated: true)
           RestHelper.countryFunction(params: params as! [String : String], completion: {jsonArray,isSuccess   in
                   if isSuccess {
                       MBProgressHUD.hide(for: self.view, animated: true)
                           for js in jsonArray {
                               self.countryArray.append(js)
                           }
                       self.CountryTableView.reloadData()
                          
                      }
                  }, failure: { (jsonText, isFailure) in
                      MBProgressHUD.hide(for: self.view, animated: true)
                      if jsonText == "The network connection was lost."{
                       self.allertShow(message: jsonText, counter: 1)
                      } else {
                       self.allertShow(message: "No internet connections", counter: 1)
                      }
                  })
       }
       
       
       func allertShow(message:String, counter:Int) {
           
           let alertCont = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
           let action = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: {(_) in
           })
           alertCont.addAction(action)
           self.present(alertCont, animated: true, completion: nil)
           
       }
       
       @IBAction func refreshData(){
           self.sendRestHelper()
       }
    @IBAction func backVC(){
        self.navigationController?.popViewController(animated: true)
        }
    
   }

   extension CountryViewController:UITableViewDelegate,UITableViewDataSource{
       func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
           return self.countryArray.count
       }
       
       func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
           let obj = self.countryArray[indexPath.row]
           let idCountry = obj.id!
           let vc = self.storyboard?.instantiateViewController(identifier: "SubCountryViewController") as! SubCountryViewController
        vc.idVil = idCountry
        self.navigationController?.pushViewController(vc, animated: true)
           
       }
       
       func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
           let  cell = tableView.dequeueReusableCell(withIdentifier: "CountryTableViewCell", for: indexPath) as! CountryTableViewCell
            let obj = self.countryArray[indexPath.row]
            cell.labelCountry.text = obj.nameViloyat!
            cell.selectionStyle = .none
            return cell
       }

}

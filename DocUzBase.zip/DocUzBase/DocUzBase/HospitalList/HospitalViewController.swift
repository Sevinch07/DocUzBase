
import UIKit
import MBProgressHUD
import SDWebImage

class HospitalViewController: UIViewController {
    
    var heightSize:CGFloat = 0.0
    var widthSize:CGFloat = 0.0
    
    var topHospitalArray=[TopHospitalModel]()
    
    @IBOutlet weak var hospitalTableView:UITableView!
    
    @IBOutlet weak var revealButton:UIButton!
    @IBOutlet weak var refreshButton:UIButton!
    @IBOutlet weak var barButton:UIButton!
    
    @IBOutlet weak var customBar:UIView!
    @IBOutlet weak var subCustomBar:UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.topHospitalArray.removeAll()
        
        heightSize = self.view.frame.size.height
        widthSize = self.view.frame.size.width
        
        let revealViewController = self.revealViewController()
        revealButton.addTarget(revealViewController, action: #selector(SWRevealViewController.revealToggle(_:)), for: .touchUpInside)
        self.view.addGestureRecognizer(self.revealViewController()!.panGestureRecognizer())
        self.revealViewController()?.rearViewRevealWidth = 200
        
        self.revealButton.layer.borderWidth = 3
        self.revealButton.layer.borderColor = UIColor(red:230/255, green:112/255, blue:18/255, alpha: 1).cgColor
        self.revealButton.layer.cornerRadius = 15.0
        self.revealButton.clipsToBounds = true
        
        self.refreshButton.layer.borderWidth = 3
        self.refreshButton.layer.borderColor = UIColor(red:230/255, green:112/255, blue:18/255, alpha: 1).cgColor
        self.refreshButton.layer.cornerRadius = 15.0
        self.refreshButton.clipsToBounds = true
        
        self.customBar.layer.borderWidth = 3
        self.customBar.layer.borderColor = UIColor(red:230/255, green:112/255, blue:18/255, alpha: 1).cgColor
        self.customBar.layer.cornerRadius = 35.0
        self.customBar.clipsToBounds = true
        
        self.subCustomBar.layer.borderWidth = 3
        self.subCustomBar.layer.borderColor = UIColor(red:255/255, green:255/255, blue:255/255, alpha: 1).cgColor
        self.subCustomBar.layer.cornerRadius = 20.0
        self.subCustomBar.clipsToBounds = true
        self.sendRestHelper()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        heightSize = self.view.frame.size.height
        widthSize = self.view.frame.size.width
    }
    
    
    func sendRestHelper() {
        self.topHospitalArray.removeAll()
        self.hospitalTableView.reloadData()
        let params = ["login":RestHelper.log["login"], "password":RestHelper.log["password"]]
        MBProgressHUD.showAdded(to: self.hospitalTableView, animated: true)
        RestHelper.topHospitalsFunction(params: params as! [String : String], completion: {jsonArray,isSuccess   in
                if isSuccess {
                    MBProgressHUD.hide(for: self.hospitalTableView, animated: true)
                        for js in jsonArray {
                            self.topHospitalArray.append(js)
                        }
                    self.hospitalTableView.reloadData()
                       
                   }
               }, failure: { (jsonText, isFailure) in
                   MBProgressHUD.hide(for: self.hospitalTableView, animated: true)
                   if jsonText == "The network connection was lost."{
                    self.allertShow(message: jsonText, counter: 1)
                   } else {
                    self.allertShow(message: "No internet connections", counter: 1)
                   }
               })
    }
    
    
    func allertShow(message:String, counter:Int) {
        
        let alertCont = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        let action = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: {(_) in
        })
        alertCont.addAction(action)
        self.present(alertCont, animated: true, completion: nil)
        
    }
    
    @IBAction func refreshData(){
        self.sendRestHelper()
    }
    
    
    @IBAction func specialist(){
        let vc  = self.storyboard?.instantiateViewController(identifier: "CountryViewController") as! CountryViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}

extension HospitalViewController:UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.topHospitalArray.count
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let obj = self.topHospitalArray[indexPath.row]
        let idHospitals = obj.id!
        let nameHospitals = obj.hospital_name!
        let vc = self.storyboard?.instantiateViewController(identifier: "DocHospitalTopListViewController") as! DocHospitalTopListViewController
        vc.id_hospitals = idHospitals
        vc.name_hospital = nameHospitals
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let  cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath) as! TableViewCell
        let obj = self.topHospitalArray[indexPath.row]
        cell.labelName.text = obj.hospital_name!
        let text = RestHelper.BaseURL + obj.image!
        
        if obj.image! == "" {
            cell.img.image = UIImage(named: "icon")
        } else {
            let url = URL(string: text)
            cell.img?.sd_setImage(with: url)
        }
        cell.img.layer.borderWidth = 3
        cell.img.layer.borderColor = UIColor(red:230/255, green:112/255, blue:18/255, alpha: 1).cgColor
        cell.img.layer.cornerRadius = 10.0
        cell.img.clipsToBounds = true
        
        cell.selectionStyle = .none
        return cell
    }
    
    
    
    
}


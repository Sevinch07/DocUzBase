//
//  DocInfoViewCollectionViewCell.swift
//  DocUzBase
//
//  Created by Qodir on 06.04.2023.
//  Copyright © 2023 Qodir. All rights reserved.
//

import UIKit

class DocInfoViewCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imageforCell:UIImageView!
}

import UIKit
import MBProgressHUD

class DocTimeViewController: UIViewController {

    var id_doc = ""
    var name_doc = ""
    
    var doc_time_array = [DocTimeModel]()
    
    @IBOutlet weak var doc_time:UITableView!
    
    @IBOutlet weak var revealButton:UIButton!
    
    @IBOutlet weak var doc_nameLabel:UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.doc_time_array.removeAll()
        
        self.revealButton.layer.borderWidth = 3
        self.revealButton.layer.borderColor = UIColor(red:230/255, green:112/255, blue:18/255, alpha: 1).cgColor
        self.revealButton.layer.cornerRadius = 15.0
        self.revealButton.clipsToBounds = true
        
        self.doc_nameLabel.layer.borderWidth = 3
        self.doc_nameLabel.layer.borderColor = UIColor(red:230/255, green:112/255, blue:18/255, alpha: 1).cgColor
        self.doc_nameLabel.layer.cornerRadius = 15.0
        self.doc_nameLabel.clipsToBounds = true
        self.doc_nameLabel.text = self.name_doc
        self.sendRestHelper()
              
    }
    
    @IBAction func backVC(){
        self.navigationController?.popViewController(animated: true)
    }
    
    func sendRestHelper() {
        let params = ["login":RestHelper.log["login"], "password":RestHelper.log["password"],"doc_id":self.id_doc]
        MBProgressHUD.showAdded(to: self.view, animated: true)
        RestHelper.docDataFunction(params: params as! [String : String], completion: {jsonObj,isSuccess   in
            if isSuccess {
                    MBProgressHUD.hide(for: self.view, animated: true)
                for js in jsonObj {
                    let f = DocTimeModel()
                    f.data = js.data
                    f.firs_time = js.firs_time
                    f.and_time = js.and_time
                    f.time_id = js.time_id
                    self.doc_time_array.append(f)
                        }
                self.doc_time.reloadData()
                   }
               }, failure: { (jsonText, isFailure) in
                   MBProgressHUD.hide(for: self.view, animated: true)
                   if jsonText == "The network connection was lost."{
                    self.allertShow(message: jsonText, counter: 1)
                   } else {
                    self.allertShow(message: "Bazada ma'lumot topilmadi", counter: 1)
                   }
               })
    }
    
    func allertShow(message:String, counter:Int) {
        if counter == 1 {
            let alertCont = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
            let action = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: {(_) in
                if counter == 1 {
                    self.navigationController?.popViewController(animated: true)
                }
            })
            alertCont.addAction(action)
            self.present(alertCont, animated: true, completion: nil)
        } else {
            
        }
    }
    
}

extension DocTimeViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        self.doc_time_array.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let  cell = tableView.dequeueReusableCell(withIdentifier: "DocTimeTableViewCell", for: indexPath) as! DocTimeTableViewCell
       
        let obj = self.doc_time_array[indexPath.row]
        
        let text = "\n" + "Sana: " + obj.data! + "\n" + "\n" + "Bo`sh vaqt oralig`i: " + obj.firs_time! + " - " + obj.and_time! + "\n"
        
        cell.timeLabel.text = text
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let obj_doc = self.doc_time_array[indexPath.row]
        let vc = self.storyboard?.instantiateViewController(identifier: "BookDoctorViewController") as! BookDoctorViewController
        vc.doc_id = self.id_doc
        vc.time_id = obj_doc.time_id!
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
}

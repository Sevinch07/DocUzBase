//
//  HospitalCollectionViewCell.swift
//  DocUzBase
//
//  Created by Qodir on 24.03.2023.
//  Copyright © 2023 Qodir. All rights reserved.
//

import UIKit

class HospitalCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var img:UIImageView!
    @IBOutlet weak var labelName:UILabel!
}


import UIKit

class StoryAccauntViewController: UIViewController {
    
    var heightSize:CGFloat = 0.0
    var widthSize:CGFloat = 0.0
    
    var storyAccaunt = ArchiveModel()
    @IBOutlet weak var revealButton:UIButton!
   
    @IBOutlet weak var barButton:UIButton!
    
    @IBOutlet weak var customBar:UIView!
    @IBOutlet weak var subCustomBar:UIView!
    
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.revealButton.layer.borderWidth = 3
        self.revealButton.layer.borderColor = UIColor(red:230/255, green:112/255, blue:18/255, alpha: 1).cgColor
        self.revealButton.layer.cornerRadius = 15.0
        self.revealButton.clipsToBounds = true
        
        self.customBar.layer.borderWidth = 3
        self.customBar.layer.borderColor = UIColor(red:230/255, green:112/255, blue:18/255, alpha: 1).cgColor
        self.customBar.layer.cornerRadius = 35.0
        self.customBar.clipsToBounds = true
        
        self.subCustomBar.layer.borderWidth = 3
        self.subCustomBar.layer.borderColor = UIColor(red:255/255, green:255/255, blue:255/255, alpha: 1).cgColor
        self.subCustomBar.layer.cornerRadius = 20.0
        self.subCustomBar.clipsToBounds = true
        
        
        self.heightSize = self.view.frame.size.height
        self.widthSize = self.view.frame.size.width
    }
    

    @IBAction func backVC(){
        self.navigationController?.popViewController(animated:  true)
    }

}
extension StoryAccauntViewController:UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let  cell = tableView.dequeueReusableCell(withIdentifier: "ArchiveTableViewCell", for: indexPath) as! ArchiveTableViewCell
       
        var diagnostic_test = ""
              var answer = ""
              var i = 1;
              for obj in self.storyAccaunt.diagnostic_test {
                  let counter = self.storyAccaunt.diagnostic_test.count
                  if i != counter {
                      diagnostic_test  = diagnostic_test + obj! + ", "
                      i += 1
                  } else {
                      diagnostic_test  = diagnostic_test + obj!
                  }
                  
              }
              
              i = 1
              for obj in self.storyAccaunt.natija {
                  let counter1 = self.storyAccaunt.natija.count
                  if i != counter1 {
                      answer  = answer + obj! + ", "
                      i += 1
                  } else {
                      answer  = answer + obj!
                  }
              }
              
              let informationText = self.storyAccaunt.data! + ".\n\n" + self.storyAccaunt.hospital_name! + ".\n" + "Shifokor: " + self.storyAccaunt.doc_name! + "\nTashxis:" + self.storyAccaunt.doc_diagnos! + ".\n\n" + "Diagnostik markaz nomi:" + "\n\t" + self.storyAccaunt.diagnosSentre_name! + ".\n\n" + "Tahlil turlari: " + "\n\t" + diagnostic_test + "\n\n" + "Tahlil natijalari: " + "\n\t" + answer + "\n\n" + "Shifokor tavsiyasi:" + "\n\t" + self.storyAccaunt.doc_prescription!
        
        cell.informationLabel.text = informationText
        
        cell.selectionStyle = .none
        return cell
    }
    
    
    
    
}


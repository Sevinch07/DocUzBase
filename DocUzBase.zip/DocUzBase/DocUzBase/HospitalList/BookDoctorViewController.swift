import UIKit
import MBProgressHUD

class BookDoctorViewController: UIViewController {

        var time_id = ""
        var doc_id = ""
    
    //@IBOutlet weak var doc_time:UITableView!
    //@IBOutlet weak var customBar:UIView!
    @IBOutlet weak var subCustomBar:UIView!
    @IBOutlet weak var revealButton:UIButton!
    @IBOutlet weak var payMent:UIButton!
   // @IBOutlet weak var orderHistory:UIButton!
   // @IBOutlet weak var doc_nameLabel:UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.revealButton.layer.borderWidth = 3
               self.revealButton.layer.borderColor = UIColor(red:230/255, green:112/255, blue:18/255, alpha: 1).cgColor
               self.revealButton.layer.cornerRadius = 15.0
               self.revealButton.clipsToBounds = true
        
        self.payMent.layer.borderWidth = 3
        self.payMent.layer.borderColor = UIColor(red:255/255, green:255/255, blue:255/255, alpha: 1).cgColor
        self.payMent.layer.cornerRadius = 15.0
        self.payMent.clipsToBounds = true
        
//        self.orderHistory.layer.borderWidth = 3
//        self.orderHistory.layer.borderColor = UIColor(red:255/255, green:255/255, blue:255/255, alpha: 1).cgColor
//        self.orderHistory.layer.cornerRadius = 15.0
//        self.orderHistory.clipsToBounds = true
        
//        self.customBar.layer.borderWidth = 3
//        self.customBar.layer.borderColor = UIColor(red:255/255, green:255/255, blue:255/255, alpha: 1).cgColor
//        self.customBar.layer.cornerRadius = 20.0
//        self.customBar.clipsToBounds = true
//
        self.subCustomBar.layer.borderWidth = 3
        self.subCustomBar.layer.borderColor = UIColor(red:255/255, green:255/255, blue:255/255, alpha: 1).cgColor
        self.subCustomBar.layer.cornerRadius = 20.0
        self.subCustomBar.clipsToBounds = true
        
        self.sendRestHelper()
    }
    

   
    func sendRestHelper() {
        let  id =  UserDefaults.standard.string(forKey: "id")
        let params = ["login":RestHelper.log["login"], "password":RestHelper.log["password"],"id_accaunt":id!, "time_id":self.time_id]
        MBProgressHUD.showAdded(to: self.view, animated: true)
        RestHelper.bookВctorFunction(params: params as! [String : String], completion: {jsonObj,isSuccess   in
            if isSuccess {
                    MBProgressHUD.hide(for: self.view, animated: true)
                
                
                let textForAllert = "Siz shifokor qabuliga yozdirildingiz, 10 daqiqa mobaynida " + jsonObj + " so`m miqdoridagi to`lovni amalga oshiring"
                    self.allertShow(message: textForAllert, counter: 2)
                
                   }
               }, failure: { (jsonText, isFailure) in
                   MBProgressHUD.hide(for: self.view, animated: true)
                   if jsonText == "The network connection was lost."{
                    self.allertShow(message: jsonText, counter: 1)
                   } else {
                    self.allertShow(message: "Bazada ma'lumot topilmadi", counter: 1)
                   }
               })
    }
    
    func allertShow(message:String, counter:Int) {
        if counter == 1 {
            let alertCont = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
            let action = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: {(_) in
                if counter == 1 {
                    self.navigationController?.popViewController(animated: true)
                }
            })
            alertCont.addAction(action)
            self.present(alertCont, animated: true, completion: nil)
        } else {
            let alertCont = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
            let action = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: {(_) in
            })
            alertCont.addAction(action)
            self.present(alertCont, animated: true, completion: nil)
        }
    }
    
    @IBAction func backVC(){
        self.navigationController?.popViewController(animated: true)
    }

    @IBAction func payMentButton(){
        let textForAllert = "Profilaktika ishlari olib borilmoqda. Noqulaylik uchun uzr!!!"
        self.allertShow(message: textForAllert, counter: 2)
    }
    
    /*
    @IBAction func orderHistoryButton(){
        let  id =  UserDefaults.standard.string(forKey: "id")
        let params = ["login":RestHelper.log["login"], "password":RestHelper.log["password"],"id_accaunt":id!]
        MBProgressHUD.showAdded(to: self.view, animated: true)
        RestHelper.userOrderHistoryFunction(params: params as! [String : String], completion: {jsonObj,isSuccess   in
            if isSuccess {
                    MBProgressHUD.hide(for: self.view, animated: true)
                
    
                
                   }
               }, failure: { (jsonText, isFailure) in
                   MBProgressHUD.hide(for: self.view, animated: true)
                   if jsonText == "The network connection was lost."{
                    self.allertShow(message: jsonText, counter: 1)
                   } else {
                    self.allertShow(message: "Bazada ma'lumot topilmadi", counter: 1)
                   }
               })
    }
    */
}

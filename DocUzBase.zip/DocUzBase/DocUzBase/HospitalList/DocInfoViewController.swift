import UIKit
import MBProgressHUD
import SDWebImage

class DocInfoViewController: UIViewController {
    
    var id_doc = ""
    var phoneNumber = ""
    
    var heightSize:CGFloat = 0.0
    var widthSize:CGFloat = 0.0
    
    var collectionViewArray = [String]()
    
    @IBOutlet weak var docImage:UIImageView!
    
    @IBOutlet weak var imageDoc:NSLayoutConstraint!
    
    @IBOutlet weak var customBar:UIView!
    @IBOutlet weak var subCustomBar:UIView!
    
    @IBOutlet weak var revealButton:UIButton!
    @IBOutlet weak var callButton:UIButton!
    @IBOutlet weak var onlineRegistrationButton:UIButton!
    
    @IBOutlet weak var doc_nameLabel:UILabel!
    @IBOutlet weak var commentLabel:UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.imageDoc.constant = 0.0
        
        self.revealButton.layer.borderWidth = 3
        self.revealButton.layer.borderColor = UIColor(red:230/255, green:112/255, blue:18/255, alpha: 1).cgColor
        self.revealButton.layer.cornerRadius = 15.0
        self.revealButton.clipsToBounds = true
        
        self.callButton.layer.borderWidth = 3
        self.callButton.layer.borderColor = UIColor(red:255/255, green:255/255, blue:255/255, alpha: 1).cgColor
        self.callButton.layer.cornerRadius = 15.0
        self.callButton.clipsToBounds = true
        
        self.onlineRegistrationButton.layer.borderWidth = 3
        self.onlineRegistrationButton.layer.borderColor = UIColor(red:255/255, green:255/255, blue:255/255, alpha: 1).cgColor
        self.onlineRegistrationButton.layer.cornerRadius = 15.0
        self.onlineRegistrationButton.clipsToBounds = true
        
        self.docImage.layer.borderWidth = 3
        self.docImage.layer.borderColor = UIColor(red:230/255, green:112/255, blue:18/255, alpha: 1).cgColor
        self.docImage.layer.cornerRadius = 20.0
        self.docImage.clipsToBounds = true
        
        self.customBar.layer.borderWidth = 3
        self.customBar.layer.borderColor = UIColor(red:255/255, green:255/255, blue:255/255, alpha: 1).cgColor
        self.customBar.layer.cornerRadius = 20.0
        self.customBar.clipsToBounds = true
        
        self.subCustomBar.layer.borderWidth = 3
        self.subCustomBar.layer.borderColor = UIColor(red:255/255, green:255/255, blue:255/255, alpha: 1).cgColor
        self.subCustomBar.layer.cornerRadius = 20.0
        self.subCustomBar.clipsToBounds = true
        self.heightSize = self.view.frame.size.height
        self.widthSize = self.view.frame.size.width
        self.collectionViewArray.removeAll()
        self.sendRestHelper()
    }
    
    @IBAction func backVC(){
        self.navigationController?.popViewController(animated: true)
    }
    
    func sendRestHelper() {
        self.collectionViewArray.removeAll()
        let params = ["login":RestHelper.log["login"], "password":RestHelper.log["password"],"id_doc":self.id_doc]
        MBProgressHUD.showAdded(to: self.view, animated: true)
        RestHelper.docInfoFunction(params: params as! [String : String], completion: {jsonObj,isSuccess   in
            if isSuccess {
                    MBProgressHUD.hide(for: self.view, animated: true)
                for js in jsonObj.image {
                    self.collectionViewArray.append(js!)
                        }
                let isImage = self.collectionViewArray[0]
                
                if isImage != "doctors_image/default.jpg"  {
                    let text = RestHelper.BaseURL + self.collectionViewArray[0]
                    let url = URL(string: text)
                    self.docImage.sd_setImage(with: url)
                    self.imageDoc.constant = 200.0
                }
                self.doc_nameLabel.text = jsonObj.name
                self.commentLabel.text = "\t" + jsonObj.coment!
                self.revealButton.isHidden = false
                self.customBar.isHidden = false
                self.docImage.isHidden = false
                self.commentLabel.isHidden = false
                self.callButton.isHidden = false
                self.onlineRegistrationButton.isHidden = false
                self.phoneNumber = jsonObj.phone!
                self.callButton.addTarget(self, action: #selector(DocInfoViewController.callPhone), for: .touchUpInside)
                   }
               }, failure: { (jsonText, isFailure) in
                   MBProgressHUD.hide(for: self.view, animated: true)
                   if jsonText == "The network connection was lost."{
                    self.allertShow(message: jsonText, counter: 1)
                   } else {
                    self.allertShow(message: "No internet connections", counter: 1)
                   }
               })
    }
    
    func allertShow(message:String, counter:Int) {
        let alertCont = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        let action = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: {(_) in
            if counter == 1 {
                self.navigationController?.popViewController(animated: true)
            }
        })
        alertCont.addAction(action)
        self.present(alertCont, animated: true, completion: nil)
        
    }
    
    @objc func callPhone (sender:UIButton){
        let alertCont = UIAlertController(title: "CONFIRM", message: "", preferredStyle: UIAlertController.Style.alert)
          let action = UIAlertAction(title: "YES", style: UIAlertAction.Style.destructive, handler: {(_) in
            let text = "telprompt://" + self.phoneNumber
              guard let number = URL(string: text) else { return }
              if #available(iOS 10.0, *) {
                  UIApplication.shared.open(number)
              } else {
                  UIApplication.shared.openURL(number)
              }
          })
          alertCont.addAction(action)
          let cancel = UIAlertAction(title: "NO", style: UIAlertAction.Style.destructive, handler: nil)
          alertCont.addAction(cancel)
          present(alertCont, animated: true, completion: nil)
      }
    
    @IBAction func timeDoctor(){
    let vc = storyboard?.instantiateViewController(identifier: "DocTimeViewController") as! DocTimeViewController
    vc.id_doc = self.id_doc
    vc.name_doc = self.doc_nameLabel.text!
    self.navigationController?.pushViewController(vc, animated: true)
    }
}
